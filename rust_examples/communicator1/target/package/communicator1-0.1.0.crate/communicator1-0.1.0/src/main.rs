extern crate communicator1;
fn main() {
    communicator1::client::connect();
}