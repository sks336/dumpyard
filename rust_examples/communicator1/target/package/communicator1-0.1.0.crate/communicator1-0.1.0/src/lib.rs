pub mod client;
mod network;

/// Adds one to the number given.
///
/// # Examples
///
/// ```
/// let five = 5;
///
/// assert_eq!(6, my_crate::add_one(5));
/// ```
pub fn add_one(x: i32) -> i32 {
x + 1
}



//mod server;

/* mod client;
mod network; */

/* mod client;
mod network {
    fn connect() {
    }
    mod server {
        fn connect() {
        }
    }
} */


// client, network, network:server

/* mod client {
    fn connect() {
    }
}
mod network {
    fn connect() {
    }
    mod server {
        fn connect() {
        }
    }
} */

/*mod network {
    fn connect() {
    }
    mod client {
        fn connect() {
        }
    }
} */


/*mod network {
    fn connect() {
    }
}
mod client {
    fn connect() {
    }
}*/
